import React from 'react'
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
// import ReactGrid from './components/ReactGrid';
import DragDrop from './components/DragDrop';

const App = () => {
  return (

    <DndProvider backend={HTML5Backend}>

      {/* <div className='App'><ReactGrid /></div> */}
      <div className='App'><DragDrop /></div>
    </DndProvider>
  )
}

export default App