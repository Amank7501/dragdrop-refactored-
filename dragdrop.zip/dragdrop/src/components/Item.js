import React from 'react'
import { useDrag } from 'react-dnd'

const Item = ({picture}) => {

    const [{ isDragging }, drag] = useDrag(() => ({
        type: "text",
        item:{id:picture.id},
        collect: (monitor) => ({
            isDragging: !!monitor.isDragging(),
        }),
    }))

    

  return (
    <div>
        
        <div class="accordion-item">
                    <h2 class="accordion-header" id={picture.id}>
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target={`#collapse${picture.id}`} aria-expanded="true" aria-controls="collapseOne">
                            Item {picture.id}
                        </button>
                    </h2>
                    <div id={`collapse${picture.id}`} class="accordion-collapse collapse " aria-labelledby={picture.id} data-bs-parent="#accordionExample">
                        <div class="accordion-body" ref={drag}>
                            {picture.url}
                        </div>
                    </div>
                </div>

    </div>
  )
}

export default Item