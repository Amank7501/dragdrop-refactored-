import React, { useEffect, useRef, useState } from 'react';
import Item from './Item';
import Picture from './Picture';
import { useDrop } from 'react-dnd';
import Container from './Container';

const DragDrop = () => {
  const [container, setContainer] = useState([]);
  const [board, setBoard] = useState([]);

  const addImageToBoard = (id) => {
    const boardItem = PictureList.find((picture) => id === picture.id);
    setBoard((board) => [...board, { ...boardItem }]);
  };
  // const addImageToBoard = (id, left, top) => {
  //   const boardItem = PictureList.find((picture) => id === picture.id);
  //   setBoard((board) => [...board, { ...boardItem, left, top }]);
  // };
  const addImageToContainer = (id) => {
    const containerItem = PictureList.find((picture) => id === picture.id);
    setContainer((container) => [...container, containerItem]);
  };

  const [{ isOverBoard }, dropBoard] = useDrop(() => ({
    accept: 'text'||'input'||'button',
    drop: (item, monitor) => {
      // const delta = monitor.getClientOffset();
      // const boardRect = monitor.getSourceClientOffset();
      // const left = delta.x - boardRect.x;
      // const top = delta.y - boardRect.y;
      // console.log("left: " + left + "top: " + top);
      // addImageToBoard(item.id, left, top);
      if (!monitor.didDrop()) {
        addImageToBoard(item.id);
      }
    },
    collect: (monitor) => ({
      isOverBoard: !!monitor.isOver(),
    }),
  }));

  const [{ isOverContainer }, dropContainer] = useDrop(() => ({
    accept: 'text',
    drop: (item, monitor) => {
      if (!monitor.didDrop()) {
        addImageToContainer(item.id);
      }
    },
    collect: (monitor) => ({
      isOverContainer: !!monitor.isOver(),
    }),
  }));

  const PictureList = [
    {
      id: 1,
      type: 'input',
      url: <div><input className='form-control' /></div>,
    },
    {
      id: 2,
      type: 'button',
      url: <div className=''><button className='btn btn-success border rounded '>Submit</button></div>,
    },
    {
      id: 3,
      type: 'input',
      url: <div><input className='form-control ' /></div>,
    },
    {
      id: 4,
      type: 'button',
      url: <div className=''><button className='btn btn-danger border rounded '>Cancel</button></div>,
    },
    {
      id: 5,
      type: 'container',
      url: <div className='border ' style={{ height: '200px' }} ref={dropContainer}>
        {container.map((picture, i) => (
          <Picture key={i} id={picture.id} url={picture.url} />
        ))}
      </div>,
    },
    
  ];


  const newX = useRef(0);
  const newY = useRef(0);
  const startX = useRef(0);
  const startY = useRef(0);
  const cardRef = useRef(null);

  useEffect(() => {
    const card = cardRef.current;

    if (card) {
      const mouseDown = (e) => {
        startX.current = e.clientX;
        startY.current = e.clientY;

        document.addEventListener('mousemove', mouseMove);
        document.addEventListener('mouseup', mouseUp);
        console.log("Mouse down at: ", { startX: startX.current, startY: startY.current });
      };

      const mouseMove = (e) => {
        newX.current = startX.current - e.clientX;
        newY.current = startY.current - e.clientY;

        startX.current = e.clientX;
        startY.current = e.clientY;

        card.style.top = `${card.offsetTop - newY.current}px`;
        card.style.left = `${card.offsetLeft - newX.current}px`;

        console.log("Mouse move at: ", { newX: newX.current, newY: newY.current });
      };

      const mouseUp = (e) => {
        document.removeEventListener('mousemove', mouseMove);
        document.removeEventListener('mouseup', mouseUp);
        console.log("Mouse up at: ", { endX: e.clientX, endY: e.clientY });
      };

      card.addEventListener('mousedown', mouseDown);

      return () => {
        card.removeEventListener('mousedown', mouseDown);
      };
    }
  }, []);


  return (
    <>
      <div className='container bg-danger h-50 w-50' style={{ cursor: 'pointer' }}>
        <div ref={cardRef} style={{ position: 'absolute' }}>hii</div>
      </div>
      <div className='d-flex gap-5 m-5'>
        <div className="accordion w-25" id="accordionExample">
          {PictureList.map((picture) => (
            <Item key={picture.id} picture={picture} />
          ))}
        </div>
        <div className='Board border border-3 d-flex flex-column gap-2' ref={dropBoard} style={{ width: '75%', height: 'auto', minHeight: '700px' }} >
          {/* 
          <div className=' w-50 h-50 row '  >
            <div className='col border' >
              Col1
            </div>
            <div className='col border' > Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> {board.map((picture, i) => (
                picture.type !== 'container' ? <Picture key={i} id={picture.id} url={picture.url} style={{ position: 'absolute', left: picture.left, top: picture.top }} /> : <Container key={i} id={picture.id} url={picture.url} />
              ))}</div>
            <div className='col border'  > {board.map((picture, i) => (
                picture.type !== 'container' ? <Picture key={i} id={picture.id} url={picture.url} style={{ position: 'absolute', left: picture.left, top: picture.top }} /> : <Container key={i} id={picture.id} url={picture.url} />
              ))}
          </div></div> */}


          {board.map((picture, i) => (
            picture.type !== 'container' ? <Picture key={i} id={picture.id} url={picture.url} style={{ position: 'absolute', left: picture.left, top: picture.top }} /> : <Container className=' ' key={i} id={picture.id} url={picture.url} />
          ))}

          {/* <div className=' w-50 h-50 row' >
            <div className='col border'>

          col1

            </div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
          </div> */}
          {/* <div className='bg-danger w-50 h-50 row' >
            <div className='col border'>
Col1 


            </div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
            <div className='col border'> Col2</div>
          </div> */}
        </div>
      </div>
    </>
  );
}

export default DragDrop;
