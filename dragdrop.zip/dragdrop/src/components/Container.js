import React, { useState } from 'react';
import { useDrop } from 'react-dnd';
import Picture from './Picture';

const Container = ({ id, url }) => {
  const [containerBoard, setContainerBoard] = useState([]);
  const [container, setContainer] = useState([]);

  const addImageToContainerBoard = (id) => {
    const boardItem = PictureList.find((picture) => id === picture.id);
    setContainerBoard((board) => [...board, boardItem]);
  };

  const [{ isOverContainerBoard }, dropContainerBoard] = useDrop(() => ({
    accept: 'text',
    drop: (item) => {
      addImageToContainerBoard(item.id);
    },
    collect: (monitor) => ({
      isOverContainerBoard: !!monitor.isOver(),
    }),
  }));

  const addImageToContainer = (id) => {
    const containerItem = PictureList.find((picture) => id === picture.id);
    setContainer((container) => [...container, containerItem]);
  };
  
  const [{ isOverContainer }, dropContainer] = useDrop(() => ({
    accept: 'text',
    drop: (item, monitor) => {
      if (!monitor.didDrop()) {
        addImageToContainer(item.id);
      }
    },
    collect: (monitor) => ({
      isOverContainer: !!monitor.isOver(),
    }),
  }));

  const PictureList = [
    {
      id: 1,
      type: 'input',
      url: <div><input className='form-control' /></div>,
    },
    {
      id: 2,
      type: 'button',
      url: <div className=''><button className='btn btn-success border rounded '>Submit</button></div>,
    },
    {
      id: 3,
      type: 'input',
      url: <div><input className='form-control ' /></div>,
    },
    {
      id: 4,
      type: 'button',
      url: <div className=''><button className='btn btn-danger border rounded '>Cancel</button></div>,
    },
    {
      id: 5,
      type: 'container',
      url: <div className='border' style={{width:'fit-content', height: 'auto', minHeight: '50px' }}  ref={dropContainer} >
        {containerBoard.map((picture) => (
          <Picture key={picture.id} id={picture.id} url={picture.url} />
        ))}
      </div>,
    },
    
  ];

  return (
    <div className='Board border border-1 d-flex gap-2 align-items-center w-50' style={{ width: 'auto', height: 'auto', minHeight: '50px' }} ref={dropContainerBoard}>
      {containerBoard.map((picture) => (
        <Picture key={picture.id} id={picture.id} url={picture.url} />
      ))}
    </div>
  );
}

export default Container;