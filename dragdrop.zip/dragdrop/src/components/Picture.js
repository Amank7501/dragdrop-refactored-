import React from 'react';
import { useDrag } from 'react-dnd'; // Import useDrag hook
import { HTML5Backend } from 'react-dnd-html5-backend'; // Import backend (assuming HTML5)

const Picture = ({ id, url, left, top }) => {
  // Destructure the result of useDrag hook
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'PICTURE', // Use the custom type 'PICTURE'
    item: { id }, // Pass the element's ID in the item
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));

  // Apply the drag ref to the Picture element
  return (
    <li
      ref={drag} // Assign the drag ref
      className='nav-item'
      style={{ listStyleType: 'none', left: `${left}px`, top:` ${top}px`, opacity: isDragging ? 0.5 : 1 }} // Adjust opacity on drag
    >
      {url}
    </li>
  );
};

export default Picture;